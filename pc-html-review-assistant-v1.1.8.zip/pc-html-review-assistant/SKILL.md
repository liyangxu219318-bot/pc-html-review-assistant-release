---
name: pc-html-review-assistant
description: Add the frozen PC HTML business review assistant to desktop HTML prototypes with deterministic injection. Use when Codex needs to derive review content from business rules and an existing prototype, inject the same draggable review UI and behavior every time, preserve local notes and droplet markers, or verify an existing assistant build.
---

# PC HTML Review Assistant

Inject the bundled review assistant without rewriting its HTML, CSS, JavaScript, or icon. Generate only project-specific review data. The frozen fragment and deterministic injector are the source of truth for appearance and behavior.

## Required Workflow

1. Inspect the target HTML, CSS, JavaScript, visible layers, and supplied business rules. Preserve existing flows, copy, IDs, and interactions.
2. Create a UTF-8 review-data JSON file by adapting `assets/review-data-example.json` to the actual project.
3. Keep `schemaVersion` equal to the bundled manifest version. Use a stable, prototype-specific `prototypeId` so local data survives regeneration.
4. Generate all four sections in this exact order:
   - `overview` / 讲解概要: concise PM speaking prompts covering context, roles, boundaries, structure, and decisions.
   - `flow` / 核心业务流程: project-specific reference steps covering trigger, actor action, state change, and review focus.
   - `objects` / 重点说明对象: UI areas that merit explanation and can receive droplet markers.
   - `questions` / 待确认问题: permissions, exceptions, data definitions, status rules, and operational questions.
5. Run the deterministic injector. Never copy, reconstruct, summarize, or manually edit the assistant fragment.

```bash
python scripts/inject_review_assistant.py --html "PATH/TO/prototype.html" --data "PATH/TO/review-data.json"
```

Use `--output "PATH/TO/reviewed-prototype.html"` to preserve the original prototype. The injector:

- validates the bundled fragment, icon, and schema against SHA-256 values in the manifest;
- validates review data and enforces the four-section contract;
- embeds the current robot icon as a data URI;
- inserts the assistant before `</body>` or replaces the existing assistant block;
- produces byte-identical output when run again with unchanged inputs;
- stamps the assistant version and frozen-template hash into the generated HTML;
- verifies the generated block before writing the file.

6. Run the independent post-generation check:

```bash
python scripts/inject_review_assistant.py --html "PATH/TO/reviewed-prototype.html" --verify-only
```

7. Open the output and verify the project-specific integration: trigger drag/click, outside-click close, panel CRUD, reviewed states, droplet placement and location, layered UI, inline notes, import/export, reset, and refresh persistence.

## Data Rules

- Follow `references/review-assistant-data.schema.json`.
- Use unique, stable item IDs across all sections.
- Set generated items to `status: "todo"` and `custom: false`.
- Give object items `notes: []`.
- Give question items `confirmStatus: "pending"` unless the supplied rules already resolve them.
- Derive overview and flow content from the real business rules and visible prototype. Do not leave generic placeholders.
- Keep the content concise enough to prompt a presenter instead of replacing the presentation.
- Add stable `data-review-layer-id` attributes to prototype modals, drawers, and popovers when needed for reliable droplet context. This is the only permitted target-HTML change outside the injected assistant block.

## Frozen UI Contract

The bundled assistant provides:

- a freely draggable circular robot trigger that expands to “评审助手” on hover or focus;
- a click-to-open side panel that closes on outside click;
- add, edit, delete, reviewed states, question confirmation states, and inline notes;
- droplet placement, relocation, one hover preview with current card content and notes, and layered-page location;
- layer-aware droplet visibility so markers hide and return with their modal, drawer, or popover context;
- versioned `localStorage`, legacy migration, reset, Markdown export, JSON backup, and JSON restore;
- keyboard-safe dialogs and reduced-motion handling.

Do not alter this contract while generating a prototype. Do not edit `assets/review-assistant-fragment.html`, `assets/review-assistant-manifest.json`, or assistant runtime code in generated HTML.

## Intentional Template Release

Use this only when the user explicitly asks to change the assistant product itself:

1. Edit and visually verify `assets/review-assistant-template.html` and bundled icon assets.
2. Run `python scripts/freeze_review_assistant.py` to regenerate the frozen fragment and manifest.
3. Run `python scripts/test_inject_review_assistant.py -v`.
4. Re-run the Skill validator and synchronize the installed Skill directory.
5. Increment `ASSISTANT_VERSION` in the freeze script for any visible or behavioral change. Increment `SCHEMA_VERSION` only for storage/data-contract changes with a migration plan.

## Bundled Resources

- `NOTICE.md`: required originality, authorization-boundary, and use-disclaimer notice; preserve it whenever the Skill is copied, packaged, distributed, or published.
- `scripts/inject_review_assistant.py`: required deterministic injector and verifier.
- `scripts/freeze_review_assistant.py`: release-only fragment freezer.
- `scripts/test_inject_review_assistant.py`: injection regression tests.
- `references/review-assistant-data.schema.json`: review-data contract.
- `assets/review-data-example.json`: editable project-data starting point.
- `assets/review-assistant-fragment.html`: frozen assistant implementation; never hand-edit.
- `assets/review-assistant-manifest.json`: versions and SHA-256 integrity values.
- `assets/review-assistant-template.html`: complete runnable example and release source.
- `assets/review-assistant-robot-icon.png`: current production entry icon.
- `assets/review-assistant-robot-icon-source.png`: icon source for intentional redesigns.
- `assets/review-assistant-icon.png` and `assets/review-assistant-icon-source.png`: legacy compatibility assets.

## Guardrails

- Keep prototype content and review notes local unless the user explicitly requests a server-backed workflow.
- Do not introduce external runtime dependencies into generated HTML.
- Do not change prototype business behavior while integrating the assistant.
- Fail instead of silently injecting when bundled hashes, review data, or target HTML are invalid.
- Preserve `NOTICE.md` with every distributed copy. Do not present it as an open-source license, commercial-use grant, or conclusive proof of authorship.
