#!/usr/bin/env python3
"""Freeze the current review-assistant implementation into an injectable fragment."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path


SKILL_ROOT = Path(__file__).resolve().parents[1]
TEMPLATE_PATH = SKILL_ROOT / "assets" / "review-assistant-template.html"
FRAGMENT_PATH = SKILL_ROOT / "assets" / "review-assistant-fragment.html"
ICON_PATH = SKILL_ROOT / "assets" / "review-assistant-robot-icon.png"
SCHEMA_PATH = SKILL_ROOT / "references" / "review-assistant-data.schema.json"
MANIFEST_PATH = SKILL_ROOT / "assets" / "review-assistant-manifest.json"
ASSISTANT_VERSION = "1.1.8"
SCHEMA_VERSION = "7"


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def extract_between(text: str, start: str, end: str, offset: int = 0) -> str:
    start_index = text.index(start, offset)
    end_index = text.index(end, start_index)
    return text[start_index:end_index]


def build_fragment(template: str) -> str:
    css = extract_between(
        template,
        "    #review-droplet-layer {",
        "    @media (max-width: 760px) {",
    ).rstrip()
    css += """

    @media (max-width: 760px) {
      #review-assistant-root,
      #review-assistant-root .ra-panel {
        width: 100vw;
        max-width: 100vw;
      }
    }

    @media (prefers-reduced-motion: reduce) {
      #review-assistant-root .ra-panel {
        transition: none;
      }
    }"""

    dom_start = template.index('  <div id="review-droplet-layer"')
    dom_end_marker = '  <div id="review-assistant-root" aria-live="polite"></div>'
    dom_end = template.index(dom_end_marker, dom_start) + len(dom_end_marker)
    dom = template[dom_start:dom_end].strip()

    data_start = template.index("    window.__REVIEW_ASSISTANT_INITIAL__ = {")
    data_end = template.index("\n    };", data_start) + len("\n    };")
    runtime_start = template.index("    (function () {", data_end)
    runtime_end = template.index("\n  </script>", runtime_start)
    runtime = template[runtime_start:runtime_end].rstrip()
    icon_literal = 'src="review-assistant-robot-icon.png"'
    if icon_literal not in runtime:
        raise ValueError("Robot icon reference was not found in the template runtime.")
    runtime = runtime.replace(icon_literal, 'src="__RA_ICON_DATA_URI__"', 1)

    return f"""<!-- REVIEW_ASSISTANT:START assistantVersion=__RA_ASSISTANT_VERSION__ templateSha256=__RA_TEMPLATE_SHA256__ -->
<style data-review-assistant-style>
{css}
</style>
{dom}
<script data-review-assistant-runtime>
    window.__REVIEW_ASSISTANT_INITIAL__ = __RA_INITIAL_DATA__;

{runtime}
</script>
<!-- REVIEW_ASSISTANT:END -->
"""


def main() -> None:
    template_bytes = TEMPLATE_PATH.read_bytes()
    template = template_bytes.decode("utf-8")
    fragment = build_fragment(template)
    FRAGMENT_PATH.write_text(fragment, encoding="utf-8", newline="\n")

    manifest = {
        "assistantVersion": ASSISTANT_VERSION,
        "schemaVersion": SCHEMA_VERSION,
        "fragmentSha256": sha256_bytes(FRAGMENT_PATH.read_bytes()),
        "iconSha256": sha256_bytes(ICON_PATH.read_bytes()),
        "schemaSha256": sha256_bytes(SCHEMA_PATH.read_bytes()),
        "sourceTemplateSha256": sha256_bytes(template_bytes),
    }
    MANIFEST_PATH.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    print(f"Frozen review assistant {ASSISTANT_VERSION}")
    print(f"Fragment SHA-256: {manifest['fragmentSha256']}")


if __name__ == "__main__":
    main()
