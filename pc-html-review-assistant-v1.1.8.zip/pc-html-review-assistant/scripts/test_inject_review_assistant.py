#!/usr/bin/env python3
"""Regression tests for deterministic review-assistant injection."""

from __future__ import annotations

import json
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path


SCRIPT = Path(__file__).with_name("inject_review_assistant.py")


def sample_data() -> dict:
    common = {"status": "todo", "custom": False}
    return {
        "schemaVersion": "7",
        "prototypeId": "deterministic-test",
        "title": "原型评审助手",
        "generatedAt": "2026-06-27T00:00:00+08:00",
        "sections": [
            {
                "id": "overview",
                "title": "讲解概要",
                "items": [{"id": "o1", "title": "评审目标", "body": "确认页面边界。", **common}],
            },
            {
                "id": "flow",
                "title": "核心业务流程",
                "items": [{"id": "f1", "title": "提交业务对象", "body": "检查状态流转。", **common}],
            },
            {
                "id": "objects",
                "title": "重点说明对象",
                "items": [{"id": "x1", "title": "提交按钮", "body": "说明提交条件。", "notes": [], **common}],
            },
            {
                "id": "questions",
                "title": "待确认问题",
                "items": [{"id": "q1", "title": "权限范围", "body": "确认角色权限。", "confirmStatus": "pending", **common}],
            },
        ],
    }


class InjectionTests(unittest.TestCase):
    def run_script(self, *args: str, expect_success: bool = True) -> subprocess.CompletedProcess:
        result = subprocess.run(
            [sys.executable, str(SCRIPT), *args],
            capture_output=True,
            text=True,
            encoding="utf-8",
        )
        if expect_success and result.returncode != 0:
            self.fail(result.stderr or result.stdout)
        return result

    def test_injection_is_idempotent_and_verifiable(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            html = root / "prototype.html"
            data = root / "review.json"
            html.write_text("<!doctype html><html><body><main>Demo</main></body></html>", encoding="utf-8")
            data.write_text(json.dumps(sample_data(), ensure_ascii=False), encoding="utf-8")

            self.run_script("--html", str(html), "--data", str(data))
            first = html.read_bytes()
            self.run_script("--html", str(html), "--data", str(data))
            second = html.read_bytes()
            self.assertEqual(first, second)
            text = second.decode("utf-8")
            self.assertEqual(text.count("<!-- REVIEW_ASSISTANT:START"), 1)
            self.assertIn("data:image/png;base64,", text)
            self.run_script("--html", str(html), "--verify-only")

    def test_invalid_section_order_is_rejected(self) -> None:
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            html = root / "prototype.html"
            data = root / "review.json"
            payload = sample_data()
            payload["sections"].reverse()
            html.write_text("<html><body></body></html>", encoding="utf-8")
            data.write_text(json.dumps(payload, ensure_ascii=False), encoding="utf-8")
            result = self.run_script(
                "--html", str(html), "--data", str(data), expect_success=False
            )
            self.assertNotEqual(result.returncode, 0)
            self.assertIn("sections must use this order", result.stderr)

    def test_droplet_preview_shows_current_card_content(self) -> None:
        fragment = SCRIPT.parents[1] / "assets" / "review-assistant-fragment.html"
        source = fragment.read_text(encoding="utf-8")
        self.assertIn('id="review-droplet-preview"', source)
        self.assertIn("positionDropletPreview", source)
        self.assertIn("horizontalCandidates", source)
        self.assertIn('root.querySelector(".ra-panel")', source)
        self.assertIn("scheduleDropletPreviewHide", source)
        self.assertIn('class="review-droplet-tooltip"', source)
        self.assertIn(".review-droplet:hover .review-droplet-tooltip", source)
        self.assertNotIn('title="${escapeHtml(previewText)}"', source)
        self.assertNotIn("tooltip-dock-left", source)
        self.assertIn("margin-left: -7.5px", source)
        self.assertIn("margin-top: -15px", source)
        self.assertNotIn("transform: translate(-50%, -84%)", source)
        self.assertNotIn('title="单击查看卡片，双击编辑卡片"', source)

    def test_layer_droplets_follow_layer_visibility(self) -> None:
        fragment = SCRIPT.parents[1] / "assets" / "review-assistant-fragment.html"
        source = fragment.read_text(encoding="utf-8")
        self.assertIn("getLayerContextPriority", source)
        self.assertIn('node.hasAttribute("data-review-layer-id")', source)
        self.assertIn("new MutationObserver", source)
        self.assertIn('attributeFilter: ["hidden", "class", "style", "aria-hidden", "inert", "open"]', source)
        self.assertIn('node.getAttribute("aria-hidden") === "true"', source)

    def test_interaction_highlights_are_bundled(self) -> None:
        fragment = SCRIPT.parents[1] / "assets" / "review-assistant-fragment.html"
        source = fragment.read_text(encoding="utf-8")
        self.assertIn('id="review-interaction-layer"', source)
        self.assertIn("review-interaction-highlight", source)
        self.assertIn('data-ra-action="toggle-interactions"', source)
        self.assertIn("renderInteractionHighlights", source)
        self.assertIn("isHighlightableInteraction", source)
        self.assertIn("[data-interactive]", source)
        self.assertIn("[data-review-noninteractive]", source)
        self.assertIn("[data-review-noninteractive-container]", source)

    def test_deleted_initial_items_do_not_reappear_after_refresh(self) -> None:
        fragment = SCRIPT.parents[1] / "assets" / "review-assistant-fragment.html"
        source = fragment.read_text(encoding="utf-8")
        self.assertIn("deletedItemIds", source)
        self.assertIn("deletedIds.has(item.id)", source)
        self.assertIn("state.settings.deletedItemIds.push(itemId)", source)

    def test_card_single_click_only_selects_and_double_click_marks_done(self) -> None:
        fragment = SCRIPT.parents[1] / "assets" / "review-assistant-fragment.html"
        source = fragment.read_text(encoding="utf-8")
        self.assertIn('root.addEventListener("dblclick"', source)
        self.assertIn("cardClickTimer", source)
        self.assertIn("clearTimeout(cardClickTimer)", source)
        self.assertIn("markSelected(sectionId, itemId, false)", source)
        self.assertIn('markSelected(card.getAttribute("data-section-id"), card.getAttribute("data-item-id"), true)', source)


if __name__ == "__main__":
    unittest.main()
