#!/usr/bin/env python3
"""Inject the frozen review assistant into a PC HTML prototype."""

from __future__ import annotations

import argparse
import base64
import hashlib
import json
import re
import shutil
import sys
from pathlib import Path
from typing import Any


SKILL_ROOT = Path(__file__).resolve().parents[1]
ASSETS = SKILL_ROOT / "assets"
FRAGMENT_PATH = ASSETS / "review-assistant-fragment.html"
ICON_PATH = ASSETS / "review-assistant-robot-icon.png"
SCHEMA_PATH = SKILL_ROOT / "references" / "review-assistant-data.schema.json"
MANIFEST_PATH = ASSETS / "review-assistant-manifest.json"
BLOCK_PATTERN = re.compile(
    r"<!-- REVIEW_ASSISTANT:START\b.*?<!-- REVIEW_ASSISTANT:END -->",
    re.DOTALL,
)
SECTION_IDS = ("overview", "flow", "objects", "questions")


class ValidationError(ValueError):
    pass


def sha256_file(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load_manifest() -> dict[str, str]:
    manifest = json.loads(MANIFEST_PATH.read_text(encoding="utf-8"))
    checks = {
        "fragmentSha256": FRAGMENT_PATH,
        "iconSha256": ICON_PATH,
        "schemaSha256": SCHEMA_PATH,
    }
    for field, path in checks.items():
        actual = sha256_file(path)
        if actual != manifest.get(field):
            raise ValidationError(
                f"Bundled {path.name} does not match the frozen manifest. "
                "Run freeze_review_assistant.py only when intentionally releasing a new template."
            )
    return manifest


def require_string(value: Any, path: str, allow_empty: bool = False) -> None:
    if not isinstance(value, str) or (not allow_empty and not value.strip()):
        raise ValidationError(f"{path} must be a non-empty string.")


def validate_data(data: Any, schema_version: str) -> dict[str, Any]:
    if not isinstance(data, dict):
        raise ValidationError("Review data must be a JSON object.")
    require_string(data.get("prototypeId"), "prototypeId")
    require_string(data.get("title"), "title")
    require_string(data.get("generatedAt"), "generatedAt")
    if str(data.get("schemaVersion")) != schema_version:
        raise ValidationError(f"schemaVersion must be {schema_version}.")

    sections = data.get("sections")
    if not isinstance(sections, list) or len(sections) != len(SECTION_IDS):
        raise ValidationError("sections must contain exactly overview, flow, objects, and questions.")
    actual_ids = tuple(section.get("id") for section in sections if isinstance(section, dict))
    if actual_ids != SECTION_IDS:
        raise ValidationError(f"sections must use this order: {', '.join(SECTION_IDS)}.")

    seen_ids: set[str] = set()
    for section_index, section in enumerate(sections):
        base = f"sections[{section_index}]"
        require_string(section.get("title"), f"{base}.title")
        items = section.get("items")
        if not isinstance(items, list) or not items:
            raise ValidationError(f"{base}.items must contain at least one item.")
        for item_index, item in enumerate(items):
            item_path = f"{base}.items[{item_index}]"
            if not isinstance(item, dict):
                raise ValidationError(f"{item_path} must be an object.")
            for field in ("id", "title", "body"):
                require_string(item.get(field), f"{item_path}.{field}")
            if item["id"] in seen_ids:
                raise ValidationError(f"Duplicate item id: {item['id']}")
            seen_ids.add(item["id"])
            if item.get("status") not in ("todo", "done"):
                raise ValidationError(f"{item_path}.status must be todo or done.")
            if not isinstance(item.get("custom"), bool):
                raise ValidationError(f"{item_path}.custom must be boolean.")
            if section["id"] == "objects":
                if not isinstance(item.get("notes", []), list):
                    raise ValidationError(f"{item_path}.notes must be an array.")
            if section["id"] == "questions" and item.get("confirmStatus") not in (
                "pending",
                "confirmed",
            ):
                raise ValidationError(
                    f"{item_path}.confirmStatus must be pending or confirmed."
                )
    return data


def json_for_script(data: dict[str, Any]) -> str:
    value = json.dumps(data, ensure_ascii=False, indent=2)
    return (
        value.replace("<", "\\u003c")
        .replace(">", "\\u003e")
        .replace("\u2028", "\\u2028")
        .replace("\u2029", "\\u2029")
    )


def render_fragment(data: dict[str, Any], manifest: dict[str, str]) -> str:
    fragment = FRAGMENT_PATH.read_text(encoding="utf-8")
    icon_uri = "data:image/png;base64," + base64.b64encode(ICON_PATH.read_bytes()).decode("ascii")
    rendered = (
        fragment.replace("__RA_ASSISTANT_VERSION__", manifest["assistantVersion"])
        .replace("__RA_TEMPLATE_SHA256__", manifest["fragmentSha256"])
        .replace("__RA_ICON_DATA_URI__", icon_uri)
        .replace("__RA_INITIAL_DATA__", json_for_script(data))
    )
    if "__RA_" in rendered:
        raise ValidationError("An unresolved template placeholder remains in the rendered assistant.")
    return rendered.rstrip()


def inject_html(html: str, block: str) -> str:
    matches = list(BLOCK_PATTERN.finditer(html))
    if len(matches) > 1:
        raise ValidationError("The target contains more than one review-assistant block.")
    if matches:
        return BLOCK_PATTERN.sub(lambda _: block, html, count=1)
    body_close = list(re.finditer(r"</body\s*>", html, flags=re.IGNORECASE))
    if not body_close:
        raise ValidationError("The target HTML must contain a closing </body> tag.")
    index = body_close[-1].start()
    prefix = html[:index].rstrip()
    suffix = html[index:].lstrip()
    return f"{prefix}\n\n{block}\n{suffix}"


def verify_html(html: str, manifest: dict[str, str]) -> dict[str, Any]:
    matches = list(BLOCK_PATTERN.finditer(html))
    if len(matches) != 1:
        raise ValidationError("Expected exactly one injected review-assistant block.")
    block = matches[0].group(0)
    expected_marker = (
        f"assistantVersion={manifest['assistantVersion']} "
        f"templateSha256={manifest['fragmentSha256']}"
    )
    if expected_marker not in block:
        raise ValidationError("Injected assistant version or template hash is stale.")
    required = (
        'id="review-assistant-root"',
        'id="review-droplet-layer"',
        "window.__REVIEW_ASSISTANT_INITIAL__ = ",
        "prototype-review-assistant:",
        "data:image/png;base64,",
    )
    for token in required:
        if token not in block:
            raise ValidationError(f"Injected assistant is missing required token: {token}")
    match = re.search(
        r"window\.__REVIEW_ASSISTANT_INITIAL__\s*=\s*(\{.*?\});\s*\n\s*\(function",
        block,
        flags=re.DOTALL,
    )
    if not match:
        raise ValidationError("Unable to read injected initial review data.")
    data = json.loads(match.group(1))
    return validate_data(data, manifest["schemaVersion"])


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--html", required=True, type=Path, help="Target PC prototype HTML.")
    parser.add_argument("--data", type=Path, help="Review data JSON used for injection.")
    parser.add_argument("--output", type=Path, help="Output HTML; defaults to updating --html.")
    parser.add_argument(
        "--verify-only",
        action="store_true",
        help="Verify an already injected HTML without modifying it.",
    )
    return parser.parse_args()


def main() -> int:
    args = parse_args()
    try:
        manifest = load_manifest()
        html = args.html.read_text(encoding="utf-8")
        if args.verify_only:
            verify_html(html, manifest)
            print(
                f"Verified review assistant {manifest['assistantVersion']} "
                f"({manifest['fragmentSha256'][:12]})."
            )
            return 0
        if not args.data:
            raise ValidationError("--data is required unless --verify-only is used.")
        data = json.loads(args.data.read_text(encoding="utf-8"))
        data["assistantVersion"] = manifest["assistantVersion"]
        validate_data(data, manifest["schemaVersion"])
        result = inject_html(html, render_fragment(data, manifest))
        verify_html(result, manifest)
        output = args.output or args.html
        output.parent.mkdir(parents=True, exist_ok=True)
        if output.resolve() != args.html.resolve():
            shutil.copyfile(args.html, output)
        output.write_text(result, encoding="utf-8", newline="\n")
        print(f"Injected review assistant into {output}")
        print(f"Version: {manifest['assistantVersion']}")
        print(f"Template SHA-256: {manifest['fragmentSha256']}")
        return 0
    except (OSError, json.JSONDecodeError, ValidationError, KeyError) as error:
        print(f"error: {error}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
